 
INSERT INTO `MEMBR` VALUES (1,35,'Sean','Smith',1,'Kahuna','Sean'),
           (2,44,'Paul','Bearer',7,'KemoSabe','Paul');
 