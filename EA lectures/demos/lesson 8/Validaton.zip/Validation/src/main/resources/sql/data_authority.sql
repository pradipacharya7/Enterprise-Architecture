 
 INSERT INTO `authority` VALUES (1,'ROLE_ADMIN','Sean','Sean'),
 (2,'ROLE_SUPERVISOR','Paul','Paul');


