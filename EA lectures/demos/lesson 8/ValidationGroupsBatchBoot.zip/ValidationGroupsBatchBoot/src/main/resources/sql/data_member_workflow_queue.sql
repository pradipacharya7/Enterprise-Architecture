 
 -- ID, Member ID
INSERT INTO `WorkFlowQueue` VALUES 
(1,1),
(2,2),
(3,3),
(4,4);
 