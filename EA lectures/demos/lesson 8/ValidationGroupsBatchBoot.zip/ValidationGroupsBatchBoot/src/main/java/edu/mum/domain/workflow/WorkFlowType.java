package edu.mum.domain.workflow;

public enum WorkFlowType {
	MEMBER,
	PRODUCT
	
}
