package edu.mum.validation.groups;

import javax.validation.groups.Default;

public interface Details extends Default {}
