package edu.mum.dao;

import edu.mum.domain.Group;

public interface GroupDao extends GenericDao<Group> {
      
 	}
