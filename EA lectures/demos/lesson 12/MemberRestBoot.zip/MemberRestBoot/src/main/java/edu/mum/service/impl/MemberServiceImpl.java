package edu.mum.service.impl;

import java.util.List;

import org.dozer.DozerBeanMapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.dozer.loader.api.TypeMappingOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.mum.dao.MemberDao;
import edu.mum.domain.Member;
import edu.mum.service.UserCredentialsService;

@Service
@Transactional 
public class MemberServiceImpl implements edu.mum.service.MemberService {
	

	private MemberDao memberDao;

 	UserCredentialsService credentialsService;

 	DozerBeanMapper dozerBeanMapper;
 	
 	public MemberServiceImpl(UserCredentialsService credentialsService, MemberDao memberDao, DozerBeanMapper dozerBeanMapper ) {
 		
 		this.credentialsService = credentialsService;
 		this.memberDao = memberDao;
 		
 		// Configure mapper to ignore nulls
		this.dozerBeanMapper = dozerBeanMapper;
		this.dozerBeanMapper.addMapping(new BeanMappingBuilder() {
		            protected void configure() {
		            	mapping(Member.class,Member.class,
		  				    TypeMappingOptions.mapNull(false), TypeMappingOptions.mapEmptyString(true));
		            	}
		            });

 	}
    public void save( Member member) {  		
		memberDao.save(member);
	}
	
    public void update( Member member) {  		
		memberDao.update(member);
	}
	
    public void patch( Long id, Member patchMember) {  
    	
		Member member = this.findOne(id);
  		
		// Age patch "rule" says increment age .
  		if (patchMember.getAge() != null)
  			patchMember.setAge(patchMember.getAge() + member.getAge());
 
  		// map patch values to "detached" member & update
  		dozerBeanMapper.map(patchMember,member);
  		this.update(member);

	}
	
    @Override
   	public void saveFull( Member member) {  		
  		credentialsService.save(member.getUserCredentials());
  		memberDao.save(member);
	}
  	

	public List<Member> findAll() {
		return (List<Member>)memberDao.findAll();
	}

	public Member findByMemberNumber(Integer memberId) {
		return memberDao.findByMemberNumber(memberId);
	}
 
	public Member findOne(Long id) {
		return memberDao.findOne(id);
	}
	
	public Member findOneFull(Long id) {
		Member member = this.findOne(id);
		
// OR 		"SELECT p FROM Member m JOIN FETCH m.userCredentials WHERE m.id = (:id)"
		member.getUserCredentials();
		
		return  member;
	}
	
	public List<Member> findAllJoinFetch() {
		return memberDao.findAllJoinFetch();
	}
	
 	@Override
	public List<Member> findByGraph() {
		return  memberDao.findByGraph();
	}

}
