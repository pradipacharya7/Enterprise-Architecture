package edu.mum.controller;

import java.util.List;
import java.util.Map;

import org.dozer.DozerBeanMapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.dozer.loader.api.TypeMappingOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;

import edu.mum.domain.Member;
import edu.mum.service.MemberService;

@RestController
@RequestMapping({"/members"})
public class MemberController {
	
	  private MemberService memberService;
	  
	  private ObjectMapper objectMapper;
	  
	@Autowired
	public MemberController(MemberService  memberService, MappingJackson2HttpMessageConverter springMvcJacksonConverter,DozerBeanMapper dozerBeanMapper) {
		this.memberService = memberService;
		objectMapper = springMvcJacksonConverter.getObjectMapper();
		
	}
	
	@GetMapping("")
	public List<Member>  findAll( ) {
		List<Member> memberList = memberService.findAll();
		return  memberList;
 
	}
	
  	@GetMapping("/{id}")
	public Member getMemberById(@PathVariable("id") Long id) {
		return   memberService.findOne(id);
 
	}
	   
  	@PatchMapping("/{id}")
	@ResponseStatus(value = HttpStatus.NO_CONTENT)
	public void patchMemberById(@PathVariable("id") Long id, @RequestBody Map<String,Object> patchMap) {
		
  		// Convert Patch Map to member 
  		Member patchMember = objectMapper.convertValue(patchMap, Member.class);
 
  		memberService.patch(id, patchMember);
  		
  		return ; 
	}
	   
	@PostMapping(value = "")
	@ResponseStatus(value = HttpStatus.NO_CONTENT)
	public void processAddNewMemberForm(@RequestBody Member memberToBeAdded) {
		memberService.save(memberToBeAdded);
 
	}
	
 
}
