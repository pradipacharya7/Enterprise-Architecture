package edu.mum.service.impl;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import edu.mum.domain.Product;
import edu.mum.rest.RestHttpHeader;
import edu.mum.service.ProductService;

@Service
public class ProductServiceImpl  implements ProductService {

	@Autowired
	RestHttpHeader restHelper;
	
	@Value( "${productRest.url}" )
	String productRestUrl;

	/*
	 * String baseUrl = "http://localhost:8080/MemberRest/products"; String
	 * baseUrlExtended = baseUrl + "/";
	 */
	public List<Product> findAll() {
		
		String baseUrl = productRestUrl;
		RestTemplate restTemplate = restHelper.getRestTemplate();
		HttpEntity httpEntity = new HttpEntity(restHelper.getHttpHeaders());
		ResponseEntity<Product[]> responseEntity = restTemplate.exchange(baseUrl, HttpMethod.GET, httpEntity, Product[].class);	
 		List<Product> userList = Arrays.asList(responseEntity.getBody());
		return userList;
	}

	public Product findOne(long index) {
		String baseUrl = productRestUrl + "/";
		RestTemplate restTemplate = restHelper.getRestTemplate();
		HttpEntity httpEntity = new HttpEntity(restHelper.getHttpHeaders());
		ResponseEntity<Product> responseEntity = restTemplate.exchange(baseUrl + index, HttpMethod.GET, httpEntity, Product.class);	
		Product product = responseEntity.getBody();
 		return product;
	}

	public Product findOneWithCategories(Long index) {
		String baseUrl = productRestUrl + "/";
		RestTemplate restTemplate = restHelper.getRestTemplate();
		HttpEntity httpEntity = new HttpEntity(restHelper.getHttpHeaders());
		ResponseEntity<Product> responseEntity = restTemplate.exchange(baseUrl + index + "/categories", HttpMethod.GET, httpEntity, Product.class);	
		Product product = responseEntity.getBody();
 		return product;
	}


	public Product save(Product product) {
		String baseUrl = productRestUrl;
		RestTemplate restTemplate = restHelper.getRestTemplate();
		HttpEntity<Product> httpEntity = new HttpEntity<Product>(product, restHelper.getHttpHeaders());
		product = restTemplate.postForObject(baseUrl, httpEntity, Product.class);
		return null;
	}

	@Override
	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		this.save(product);
	}
}
