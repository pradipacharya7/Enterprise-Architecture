package edu.mum.service.impl;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import edu.mum.domain.Member;
import edu.mum.rest.RestHttpHeader;
import edu.mum.service.MemberService;

@Component
public class MemberServiceImpl implements MemberService {

	@Autowired
	RestHttpHeader restHelper;

	String baseUrl = "http://localhost:8080/MemberRest/members";
	String baseUrlExtended = baseUrl + "/";

	public List<Member> findAll() {
		
		RestTemplate restTemplate = restHelper.getRestTemplate();
		HttpEntity httpEntity = new HttpEntity(restHelper.getHttpHeaders());
		ResponseEntity<Member[]> responseEntity = restTemplate.exchange(baseUrl, HttpMethod.GET, httpEntity, Member[].class);	
 		List<Member> userList = Arrays.asList(responseEntity.getBody());
		return userList;
	}

	public Member findOne(Long index) {
		RestTemplate restTemplate = restHelper.getRestTemplate();
		HttpEntity httpEntity = new HttpEntity(restHelper.getHttpHeaders());
		ResponseEntity<Member> responseEntity = restTemplate.exchange(baseUrlExtended + index, HttpMethod.GET, httpEntity, Member.class);	
		Member member = responseEntity.getBody();
 		return member;
	}

	public void partialUpdate(Long index, Map patch) {
		RestTemplate restTemplate = restHelper.getRestTemplate();
		HttpEntity httpEntity = new HttpEntity<Map>(patch,restHelper.getHttpHeaders());
		restTemplate.exchange(baseUrlExtended + index, HttpMethod.PATCH, httpEntity, Map.class);	

 		return ;
	}

	public void save(Member member) {
		RestTemplate restTemplate = restHelper.getRestTemplate();
		HttpEntity<Member> httpEntity = new HttpEntity<Member>(member, restHelper.getHttpHeaders());
		member = restTemplate.postForObject(baseUrl, httpEntity, Member.class);
		return;
	}

	@Override
	public void saveFull(Member member) {
		// TODO Auto-generated method stub
		
	}

}
