package edu.mum.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import edu.mum.domain.Address;
import edu.mum.service.AddressService;

@RestController
@RequestMapping({"/addresses"})
 public class AddressController {

	@Autowired
	AddressService addressService;
	
	@RequestMapping
	public @ResponseBody List<Address>  findAll( ) {
		return  addressService.findAll();
 
	}
	

 	
 	@RequestMapping("/{id}")
	public Address findOne(@PathVariable("id") Long id ) {

 		Address address = addressService.findOne(id);
 
 		return  address;
	}
 
 
}
