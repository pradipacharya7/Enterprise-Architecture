package edu.mum;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import edu.mum.amqp.OrderService;
import edu.mum.amqp.OrderServiceImpl;
import edu.mum.integration.OrderGateway;

@SpringBootApplication
public class AmqpPhoneBootApplication implements CommandLineRunner{

	@Autowired
	OrderService orderService;
	@Autowired
	OrderGateway orderGateway;
	 
	public static void main(String[] args) {
		SpringApplication.run(AmqpPhoneBootApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
       
        // Put order into Spring Integration through OrderGateway 
     	orderService.publish(orderGateway);
     	
     	try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		
	}

}
