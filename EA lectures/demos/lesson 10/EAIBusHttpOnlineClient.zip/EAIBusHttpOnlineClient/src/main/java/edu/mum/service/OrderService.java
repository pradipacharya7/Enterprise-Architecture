package edu.mum.service;

import edu.mum.domain.Order;

public interface OrderService {

 

 public	void addOrder(Order order);
 

}
