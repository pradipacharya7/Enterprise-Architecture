package edu.mum.builder;

import edu.mum.domain.Order;
import edu.mum.domain.OrderItem;
import edu.mum.domain.OrderPayment;
import edu.mum.domain.Address;
import edu.mum.domain.Member;

public class OrderBuilder {

     private Order order;
    
 	public OrderBuilder() {
		this.order = new Order();
	}

 	
    public OrderBuilder withOrderNumber(String orderNumber) {
        this.order.setOrderNumber(orderNumber);
        return this;
    }

    public OrderBuilder withOrderItem(OrderItem orderItem) {
        this.order.addOrderItem(orderItem);
        return this;
    }

    public OrderBuilder withOrderPayment(OrderPayment orderPayment) {
        this.order.addOrderPayment(orderPayment);
        return this;
    }


    public OrderBuilder withId(Long id) {
        this.order.setId(id);
        return this;
    }

    public Order build() {
        return order;
    }

	
}
