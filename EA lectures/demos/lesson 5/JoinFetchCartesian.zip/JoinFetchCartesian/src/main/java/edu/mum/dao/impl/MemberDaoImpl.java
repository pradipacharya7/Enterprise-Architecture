package edu.mum.dao.impl;

 

import java.util.List;

import javax.persistence.EntityGraph;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import edu.mum.dao.MemberDao;
import edu.mum.domain.Address;
import edu.mum.domain.Member;
import edu.mum.domain.Order;


@SuppressWarnings("unchecked")
@Repository
public class MemberDaoImpl extends GenericDaoImpl<Member> implements MemberDao {

	public MemberDaoImpl() {
		super.setDaoType(Member.class );
		}

	public Member findByMemberNumber(Integer number) {
	     
		Query query = entityManager.createQuery("select m from Member m  where m.memberNumber =:number");
		return (Member) query.setParameter("number", number).getSingleResult();
			     

	}

	// This will result in a Cartesian-like result 
	public List<Member> findAllJoinFetch() {
		  Query query =  entityManager.createQuery("SELECT    m FROM Member AS m JOIN FETCH m.addresses AS a");
		  List<Member> members =  query.getResultList();

		  System.out.println(" Fetch ALL Members JOINED with Address");
			 printCartesian( members, "Ignore") ;

			 return members;

	}

	// SELECT DISTINCT will remove duplicates  i.e, Cartesian
	// HOWEVER it does it with the ResultTransformer AFTER the SQL Fetch
	
	// Cartesian...
	public Member findOneJoinFetch(Long id) {
		
		  Query query = 
				entityManager.createQuery("SELECT  m FROM Member AS m JOIN FETCH m.orders as o JOIN FETCH m.addresses as a where m.id = :id");
		  
		  List<Member> members = (List<Member>)
		  query.setParameter("id",id).getResultList();
		 		
		  System.out.println(" Fetch SINGLE Member JOINED with Address AND ORDER");

			 printCartesian( members, "Print") ;
			 
			 return members.get(0);

	}


	public List<Member> findByGraph() {

	    EntityGraph graph = entityManager.getEntityGraph("graph.Member.addresses");

	    return (List<Member>) this.findAll("javax.persistence.fetchgraph",graph);
 
	}

	private void printCartesian(List<Member> members,String orderPrint) {
		
		for (Member member : members) {
		   System.out.println("Member Name : " + member.getFirstName() + "  " + member.getLastName() );
			  
			 for (Address address : member.getAddresses()) {
			 System.out.println("          Address : " + address.getCity() + "   " +
			 address.getState()); } 

			 if (orderPrint.equals("Print"))
				 for (Order order : member.getOrders()) {
					 System.out.println("          Order : " + order.getOrderNumber() );
				 } 
		}

	}

 }