SELECT * FROM eacore.membr as membr inner join eacore.address 
inner join eacore.purchaseorder 
where membr.member_id = 1 AND
membr.member_id = eacore.address.member_id AND
membr.member_id = eacore.purchaseorder.member_id;