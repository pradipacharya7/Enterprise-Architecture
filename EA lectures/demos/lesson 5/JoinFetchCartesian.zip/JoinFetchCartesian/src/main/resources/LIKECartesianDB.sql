SELECT * FROM eacore.membr as membr inner join eacore.address 
where membr.member_id = eacore.address.member_id order by membr.firstName DESC;