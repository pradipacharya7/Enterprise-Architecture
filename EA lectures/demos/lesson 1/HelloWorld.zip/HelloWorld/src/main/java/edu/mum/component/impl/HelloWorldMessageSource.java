package edu.mum.component.impl;

import edu.mum.component.MessageSource;

public class HelloWorldMessageSource implements MessageSource {
 
	public String getMessage() {
		  return "Hello World!";	}
 }
