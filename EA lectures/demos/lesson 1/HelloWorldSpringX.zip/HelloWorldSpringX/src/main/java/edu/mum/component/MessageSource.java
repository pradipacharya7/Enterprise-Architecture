package edu.mum.component;

public interface MessageSource {
   public String getMessage();
}
