package edu.mum.sender;

public interface MessageSender {
    void sendMessage(Object message);
}
