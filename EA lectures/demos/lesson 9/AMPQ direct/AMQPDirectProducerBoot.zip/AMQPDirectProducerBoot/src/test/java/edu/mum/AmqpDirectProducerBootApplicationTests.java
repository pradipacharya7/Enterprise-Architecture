package edu.mum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmqpDirectProducerBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
