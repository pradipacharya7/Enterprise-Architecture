package edu.mum;

import java.util.Arrays;
import java.util.List;

import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Declarable;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

 @Configuration
public class AmqpConfiguration {


	    @Bean
	    public AmqpAdmin amqpAdmin(ConnectionFactory connectionFactory) {
	        return new RabbitAdmin(connectionFactory);
	    }

 		
 // Declare Queues, Exchange & Bind all at once...
 		   @Bean
		   public List<Declarable> orderDirectExchangeBindings() {
		       Queue orderStoreQueue = new Queue("orderStoreQueue", true);
		       Queue orderOnlineQueue = new Queue("orderOnlineQueue", true);
		       DirectExchange orderDirectExchange = new DirectExchange("orderDirectExchange");
		    
		       List<Declarable> bindingList = Arrays.<Declarable>asList(
		    		   orderStoreQueue,
		    		   orderOnlineQueue,
		    		   orderDirectExchange,
		    	 BindingBuilder.bind(orderStoreQueue).to(orderDirectExchange).with("order.store"),
		         BindingBuilder.bind(orderOnlineQueue).to(orderDirectExchange).with("order.online"));
		       
		       return bindingList;
		   }


 		   @Bean
		    public RabbitTemplate orderStoreTemplate(ConnectionFactory connectionFactory) {
		        RabbitTemplate orderStoreTemplate= new RabbitTemplate(connectionFactory);
		        orderStoreTemplate.setRoutingKey("order.store");
		        orderStoreTemplate.setExchange("orderDirectExchange");
		        orderStoreTemplate.setReplyTimeout(2000);
		        return orderStoreTemplate;
		    }
  
 		   @Bean
		    public RabbitTemplate orderOnlineTemplate(ConnectionFactory connectionFactory) {
		        RabbitTemplate orderOnlineTemplate= new RabbitTemplate(connectionFactory);
		        orderOnlineTemplate.setRoutingKey("order.online");
		        orderOnlineTemplate.setExchange("orderDirectExchange");
		        orderOnlineTemplate.setReplyTimeout(2000);
		        return orderOnlineTemplate;
		    }
  
				   
}
