package edu.mum;

import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.rabbit.listener.adapter.MessageListenerAdapter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;

import edu.mum.amqp.DirectStoreListener;


 
@Configuration
public class AmqpConfiguration {
		   
      @Bean
    public AmqpAdmin amqpAdmin(ConnectionFactory connectionFactory) {
        return new RabbitAdmin(connectionFactory);
    }

    @Bean
		   public SimpleMessageListenerContainer directListenerContainer(ConnectionFactory connectionFactory) {
		       SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
		       container.setConnectionFactory(connectionFactory);
		       container.setQueueNames("orderStoreQueue");
		       container.setMessageListener(new MessageListenerAdapter(queueListener(),"listen"));
		       return container;
		   }
		   
		   @Bean
		   DirectStoreListener queueListener() {
			   return new DirectStoreListener();
		   }
		   
		   
}
