-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: eacore
-- ------------------------------------------------------
-- Server version	5.6.26-log
 
--TRUNCATE TABLE empties a table completely.
 
TRUNCATE TABLE `membr` ;
 


 
SET FOREIGN_KEY_CHECKS = 0; 
TRUNCATE TABLE `credentials`;
SET FOREIGN_KEY_CHECKS = 1; 
 


-- Dump completed on 2017-04-10 22:09:29
