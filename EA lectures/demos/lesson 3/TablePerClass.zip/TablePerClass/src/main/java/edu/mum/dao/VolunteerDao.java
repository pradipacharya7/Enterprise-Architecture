package edu.mum.dao;

import edu.mum.domain.Volunteer;

public interface VolunteerDao extends GenericDao<Volunteer> {
      
}
