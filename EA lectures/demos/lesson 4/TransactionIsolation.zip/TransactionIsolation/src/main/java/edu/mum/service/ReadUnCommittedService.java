package edu.mum.service;

import edu.mum.domain.Member;
 
public interface ReadUnCommittedService {

	public void readUncommitted(Member member);
 }
