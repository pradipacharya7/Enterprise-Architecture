 
INSERT INTO `MEMBR` VALUES 
(3,22,'Pete','Moss',6,'BMOC',NULL),
(4,44,'Paul','Sutton',7,'KemoSabe',NULL),
(1,35,'Sean','Smith',1,'Kahuna',NULL),
(2,59,'Bill','IsDueTime',3,'Sri',NULL),
(5,0,'Batch','OCookies',8,'Big Dog',NULL);
 