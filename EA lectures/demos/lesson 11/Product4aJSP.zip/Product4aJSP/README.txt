Model II MVC -- JSP[View] - Servlet[Controller] MVC

NOTICE: TWO Servlets to handle the resources..[GET/POST & LIST]
 
 - NOTICE Product Repository FACTORY - to "mimic" Spring managed SINGLETON  

 