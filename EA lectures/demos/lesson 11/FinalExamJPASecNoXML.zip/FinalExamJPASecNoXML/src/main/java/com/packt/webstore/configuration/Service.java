package com.packt.webstore.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.packt.webstore.service.impl")
public class Service {
   
     

}