Class level @RequestMapping example
FOLLOW ON to ProductMVCClass

See WelcomeController & ProductController for examples
Also look at ProductDetails.jsp for change to ListProducts URL
 And ListProducts.jsp for change to product URL
 
 ALSO Using JavaConfig INSTEAD of XML
 