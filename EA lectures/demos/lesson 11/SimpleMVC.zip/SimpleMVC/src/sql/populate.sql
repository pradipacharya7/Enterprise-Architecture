 
 INSERT INTO `category` VALUES (1,'Sports'), (2,'Books'), (3,'Toys');


