package edu.mum.dao;

import edu.mum.domain.BankAccount;

public interface BankAccountDao extends GenericDao<BankAccount> {
      
}
